// 拡張機能を実際のChromiumに読み込ませ、雀魂のURLで動かして確かめる。
//   - 雀魂のページの代わりに、ログインと牌譜の要求だけを行う最小ページを返す。
//   - ローカルのWebSocketサーバが雀魂の代わりに応答する(牌譜は実牌譜のデータ)。
//   - 雀魂で牌譜を開いても取り込まないことと、対局一覧のCSVからの取得を通しで確かめる。
// 取得は本番と同じ20秒間隔で動かすので、全体で2分ほどかかる。
//
// 実行: NODE_PATH=<playwright のある node_modules> node test/e2e.mjs
import { createRequire } from "node:module";
import { createServer } from "node:http";
import { createHash } from "node:crypto";
import { readFileSync, writeFileSync, mkdtempSync, mkdirSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import assert from "node:assert/strict";

const require = createRequire(import.meta.url);
const { chromium } = require("playwright");

const here = dirname(fileURLToPath(import.meta.url));
const extensionDir = join(here, "..");
const shots = process.env.SHOT_DIR || join(here, "shots");
mkdirSync(shots, { recursive: true });
const fixture = Buffer.from(readFileSync(join(here, "fixtures/record-raw.base64.txt"), "utf8").trim(), "base64");

const ORIGINAL = "260520-a9ac4630-6d4c-49e4-8f72-93d5d6080eee";
const ID_A = "261001-aaaaaaaa-1111-4111-8111-aaaaaaaaaaaa";
const ID_B = "261002-bbbbbbbb-2222-4222-8222-bbbbbbbbbbbb";
const ID_C = "261003-cccccccc-3333-4333-8333-cccccccccccc";
const ID_D = "261004-dddddddd-4444-4444-8444-dddddddddddd";
const ID_E = "261005-eeeeeeee-5555-4555-8555-eeeeeeeeeeee";
const ID_BAD = "261009-ffffffff-9999-4999-8999-ffffffffffff";
const ID_DONE = "261008-99999999-8888-4888-8888-999999999999"; // 出力済みのCSVに載っている対局
const VERSION = "web-0.11.200";
const INTERVAL_MS = 20000;
// 間隔は拡張機能が要求を送った時刻で測っている。サーバに届く時刻は数ミリ秒ずれるので、その分の幅を認める。
const JITTER_MS = 100;
const SHORT_INTERVAL_MS = 5000; // 入力欄で指定できる最短の待機時間

// ---- protobuf の最小限の読み取り(サーバ側の検査用) ----
function readVarint(bytes, position) {
  let value = 0;
  let shift = 0;
  for (;;) {
    const byte = bytes[position++];
    value |= (byte & 0x7f) << shift;
    shift += 7;
    if (!(byte & 0x80)) return [value >>> 0, position];
  }
}
function fieldsOf(bytes) {
  const fields = [];
  let position = 0;
  while (position < bytes.length) {
    let tag;
    [tag, position] = readVarint(bytes, position);
    if ((tag & 7) === 2) {
      let length;
      [length, position] = readVarint(bytes, position);
      fields.push({ id: tag >>> 3, value: bytes.subarray(position, position + length) });
      position += length;
    } else {
      let value;
      [value, position] = readVarint(bytes, position);
      fields.push({ id: tag >>> 3, value });
    }
  }
  return fields;
}

// ---- 最小のWebSocketサーバ(バイナリフレームの送受信だけ) ----
function encodeFrame(payload) {
  const length = payload.length;
  let header;
  if (length < 126) header = Buffer.from([0x82, length]);
  else if (length < 65536) header = Buffer.from([0x82, 126, length >> 8, length & 255]);
  else {
    header = Buffer.alloc(10);
    header[0] = 0x82;
    header[1] = 127;
    header.writeBigUInt64BE(BigInt(length), 2);
  }
  return Buffer.concat([header, payload]);
}

const recordRequests = []; // サーバが受け取った牌譜の要求

function respond(socket, payload) {
  if (payload[0] !== 2) return;
  const index = [payload[1], payload[2]];
  const wrapper = fieldsOf(payload.subarray(3));
  const name = wrapper.find((field) => field.id === 1).value.toString("latin1");
  const data = wrapper.find((field) => field.id === 2)?.value ?? Buffer.alloc(0);

  if (name !== ".lq.Lobby.fetchGameRecord") {
    // 牌譜ではない短い応答(取り込まれてはいけない)。
    socket.write(encodeFrame(Buffer.from([3, ...index, 0x0a, 0x00])));
    return;
  }
  const request = fieldsOf(data);
  const uuid = request.find((field) => field.id === 1).value.toString("latin1");
  recordRequests.push({
    time: Date.now(),
    uuid,
    version: request.find((field) => field.id === 2)?.value.toString("latin1"),
    extra: request.find((field) => field.id === 7)?.value,
    index: index[0] | (index[1] << 8),
  });
  if (uuid === ID_BAD) {
    // ResGameRecord{ error{ code: 1203 } }
    socket.write(encodeFrame(Buffer.from([3, ...index, 0x12, 0x05, 0x0a, 0x03, 0x08, 0xb3, 0x09])));
    return;
  }
  // 実牌譜のゲームIDだけを、要求されたIDに書き換えて返す(長さは同じ)。
  const reply = Buffer.from(fixture);
  reply[1] = index[0];
  reply[2] = index[1];
  const at = reply.indexOf(ORIGINAL, 0, "latin1");
  reply.write(uuid, at, "latin1");
  socket.write(encodeFrame(reply));
}

function startServer() {
  const server = createServer();
  server.on("upgrade", (request, socket) => {
    const accept = createHash("sha1")
      .update(request.headers["sec-websocket-key"] + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11")
      .digest("base64");
    socket.write(
      "HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n" +
        `Sec-WebSocket-Accept: ${accept}\r\n\r\n`,
    );
    let buffered = Buffer.alloc(0);
    socket.on("data", (chunk) => {
      buffered = Buffer.concat([buffered, chunk]);
      for (;;) {
        if (buffered.length < 2) break;
        let length = buffered[1] & 0x7f;
        let offset = 2;
        if (length === 126) {
          if (buffered.length < 4) break;
          length = buffered.readUInt16BE(2);
          offset = 4;
        }
        if (buffered.length < offset + 4 + length) break;
        const mask = buffered.subarray(offset, offset + 4);
        const body = buffered.subarray(offset + 4, offset + 4 + length);
        const payload = Buffer.from(body.map((byte, index) => byte ^ mask[index % 4]));
        buffered = buffered.subarray(offset + 4 + length);
        if ((chunk[0] & 0x0f) === 8) return; // close
        respond(socket, payload);
      }
    });
    socket.on("error", () => {});
  });
  return new Promise((resolve) => server.listen(0, "127.0.0.1", () => resolve(server)));
}

// 雀魂の代わりのページ。ログインし、?paipu が付いていれば自分で牌譜を1件要求する。
function gamePage(port) {
  return `<!doctype html><meta charset="utf-8"><title>fake majsoul</title><body>fake<script>
    const ascii = (text) => Array.from(text, (c) => c.charCodeAt(0));
    const field = (id, bytes) => [(id << 3) | 2, bytes.length, ...bytes];
    const request = (index, name, data) =>
      new Uint8Array([2, index & 255, index >> 8, ...field(1, ascii(name)), ...field(2, data)]);
    const socket = new WebSocket("ws://127.0.0.1:${port}/");
    socket.binaryType = "arraybuffer";
    window.received = 0;
    window.unknown = 0;
    const mine = new Set();
    // 雀魂と同じく、自分が送っていない番号の応答が届いたら数える(届いてはいけない)。
    socket.onmessage = (event) => {
      const bytes = new Uint8Array(event.data);
      if (mine.delete(bytes[1] | (bytes[2] << 8))) window.received++;
      else window.unknown++;
    };
    const send = (index, name, data) => { mine.add(index); socket.send(request(index, name, data)); };
    socket.addEventListener("open", () => {
      send(1, ".lq.Lobby.oauth2Login", [...field(2, ascii("token")), ...field(10, ascii("${VERSION}"))]);
      send(7, ".lq.Lobby.fetchGameRecordList", [0x08, 0x01]);
      send(8, ".lq.Lobby.heatbeat", []);
      if (location.search.includes("paipu")) {
        // 7番は、いまの定義には無いフィールド。雛形として丸ごと引き継がれることを確かめる。
        send(300, ".lq.Lobby.fetchGameRecord", [...field(1, ascii("${ORIGINAL}")), ...field(2, ascii("${VERSION}")), 0x38, 0x01]);
      }
    });
  </script>`;
}

const server = await startServer();
const port = server.address().port;
const context = await chromium.launchPersistentContext(mkdtempSync(join(tmpdir(), "mps-e2e-")), {
  channel: "chromium",
  headless: true,
  args: [`--disable-extensions-except=${extensionDir}`, `--load-extension=${extensionDir}`],
  viewport: { width: 1100, height: 760 },
  colorScheme: process.env.COLOR_SCHEME === "dark" ? "dark" : "light",
});

try {
  await context.grantPermissions(["clipboard-read", "clipboard-write"]);
  await context.route("https://game.mahjongsoul.com/**", (route) =>
    route.fulfill({ status: 200, contentType: "text/html", body: gamePage(port) }),
  );

  let [worker] = context.serviceWorkers();
  if (!worker) worker = await context.waitForEvent("serviceworker");
  const extensionId = new URL(worker.url()).host;
  // 保存の呼び出しを記録する。保存先を選ぶ画面は画面なしのブラウザには出ないので、
  // 「選ぶ画面を出す指定(saveAs)で呼んでいること」と「実際に保存されたファイルの中身」を確かめる。
  await worker.evaluate(() => {
    globalThis.__saves = [];
    const real = chrome.downloads.download.bind(chrome.downloads);
    chrome.downloads.download = (options) => {
      globalThis.__saves.push({ filename: options.filename, saveAs: options.saveAs, url: options.url });
      return real(options);
    };
  });
  // 「CSVを保存」を押し、保存が終わるのを待って、{ name: 既定のファイル名, text: 保存されたファイルの中身 } を返す。
  const pressSave = async (page) => {
    const before = await worker.evaluate(() => globalThis.__saves.length);
    await page.click("#save");
    await page.waitForFunction(() => document.querySelector("#done").textContent === "CSVを保存した");
    const call = await worker.evaluate((index) => globalThis.__saves[index], before);
    assert.equal(call.saveAs, true, "保存先を選ぶ画面を出す指定になっていない");
    assert.ok(call.url.startsWith("data:text/csv;charset=utf-8,"));
    const [item] = await worker.evaluate(() => chrome.downloads.search({ orderBy: ["-startTime"], limit: 1 }));
    assert.equal(item.state, "complete");
    const text = readFileSync(item.filename, "utf8");
    assert.equal(text, decodeURIComponent(call.url.slice(call.url.indexOf(",") + 1)));
    return { name: call.filename, text };
  };
  const queueOf = (page) => page.evaluate(async () => (await chrome.storage.local.get("queue")).queue);
  const gameKeys = async (page) =>
    Object.keys(await page.evaluate(() => chrome.storage.local.get(null)))
      .filter((key) => key.startsWith("game:"))
      .map((key) => key.slice(5))
      .sort();

  // ======== 雀魂で牌譜を開いても取り込まない ========

  const popup = await context.newPage();
  await popup.setViewportSize({ width: 780, height: 600 });
  await popup.goto(`chrome-extension://${extensionId}/popup/popup.html`);
  await popup.waitForSelector("#empty:not([hidden])");
  await popup.screenshot({ path: join(shots, "1-empty.png") });

  // ゲームIDを打ち込む欄は無い。取得できるのは、読み込んだ対局一覧のCSVの牌譜だけ。
  assert.equal(await popup.$("#bulk-input"), null);
  assert.equal(await popup.$("textarea"), null);
  assert.equal(await popup.textContent("#bulk-list"), "対局一覧のCSVは、まだ読み込まれていない。");
  await popup.click("#bulk-start");
  assert.equal(await popup.textContent("#bulk-message"), "先に、対局一覧のCSVを読み込んでください");

  // 対局一覧のCSV(雀魂の大会の出力と同じ見出し)。
  const files = mkdtempSync(join(tmpdir(), "mps-csv-"));
  const listRow = (link) =>
    `2026-08-01 22:08:22,2026-08-01 22:53:06,no,[JP][1]A(),34300,54.3,[JP][2]B(),25300,5.3,[JP][3]C(),22500,-17.5,[JP][4]D(),17900,-42.1,${link},`;
  const writeList = (name, uuids) => {
    const path = join(files, name);
    writeFileSync(
      path,
      "﻿開始時間,終了時間,非表示状態,1位プレイヤー名,1位PT,1位最終点数,2位プレイヤー名,2位PT,2位最終点数,3位プレイヤー名,3位PT,3位最終点数,4位プレイヤー名,4位PT,4位最終点数,牌譜リンク,備考\n" +
        uuids.map(listRow).join("\n") +
        "\n",
    );
    return path;
  };
  const list1 = writeList("202608-01.csv", [ID_A, ID_DONE, ID_B, ID_BAD, ID_E]);
  await popup.setInputFiles("#bulk-list-file", list1);
  await popup.waitForFunction(() => document.querySelector("#bulk-message").textContent.includes("202608-01.csv"));
  assert.equal(await popup.textContent("#bulk-message"), "202608-01.csv から 5 件を読み込んだ。");
  assert.equal(await popup.textContent("#bulk-list"), "取得する一覧: 202608-01.csv(5 対局、取得済み 0、残り 5)");

  // 雀魂のタブが無いときは、その旨を伝える。
  await popup.click("#bulk-start");
  await popup.waitForFunction(() => document.querySelector("#bulk-message").textContent.includes("雀魂"));
  assert.equal(await popup.textContent("#bulk-message"), "雀魂のタブが開かれていません");

  // 雀魂が自分で牌譜を開く(?paipu)。応答は雀魂に届くが、拡張機能は取り込まない。
  const game = await context.newPage();
  const pageErrors = [];
  game.on("pageerror", (error) => pageErrors.push(String(error)));
  await game.goto("https://game.mahjongsoul.com/index.html?paipu=1");
  await game.waitForFunction(() => window.received === 4);
  await popup.waitForTimeout(800);
  assert.deepEqual(pageErrors, []);
  assert.deepEqual(await gameKeys(popup), []);
  assert.equal(await popup.isVisible("#empty"), true);
  assert.equal(await popup.textContent("#count"), "");
  assert.equal(await worker.evaluate(() => chrome.action.getBadgeText({})), "");
  assert.equal(await popup.evaluate(async () => (await chrome.storage.local.get("status")).status), undefined);

  await game.reload();
  await game.waitForFunction(() => window.received === 4);
  await popup.waitForTimeout(800);
  assert.deepEqual(await gameKeys(popup), []);
  assert.deepEqual(recordRequests.map((request) => request.uuid), [ORIGINAL, ORIGINAL]); // ページ自身が送った2回だけ
  assert.deepEqual(await game.evaluate(() => [window.received, window.unknown]), [4, 0]);
  console.log("雀魂で牌譜を開いても取り込まない: ok");

  // ======== 対局一覧のCSVからの取得(バージョンはログインの通信から読む) ========

  await game.goto("https://game.mahjongsoul.com/index.html");
  await game.waitForFunction(() => window.received === 3);
  recordRequests.length = 0;

  // 出力済みのCSV(前回保存した集計のCSV)を読み込む。この対局は拡張機能には残っていない。
  const summaryCsv = join(files, "202608-01-summary.csv");
  writeFileSync(
    summaryCsv,
    `﻿ゲームID,名前,内部ID,局数,和了数,和了点合計\r\n${ID_DONE},前回A,102527752,8,2,9000\r\n${ID_DONE},前回B,2,8,0,0\r\n`,
  );
  await popup.setInputFiles("#bulk-exported-file", summaryCsv);
  await popup.waitForSelector("#bulk-exported:not([hidden])");
  const exportedText = "出力済みの 1 対局は取得せず、集計のCSVに引き継ぐ(202608-01-summary.csv)";
  assert.equal(await popup.textContent("#bulk-exported-text"), exportedText);
  assert.equal(await popup.textContent("#count"), "取得済み 0 対局、前回の出力から 1 対局");
  assert.equal(await popup.textContent("#bulk-list"), "取得する一覧: 202608-01.csv(5 対局、取得済み 0、出力済み 1、残り 4)");

  // ゲームIDの列があっても、集計の表ではないCSVは引き継げないので断る。
  const huleCsv = join(files, "other-format.csv");
  writeFileSync(huleCsv, `ゲームID,局,本場,和了者\r\n${ID_DONE},東1局,0,A\r\n`);
  await popup.setInputFiles("#bulk-exported-file", huleCsv);
  await popup.waitForFunction(() => document.querySelector("#bulk-message").textContent.includes("集計のCSVではありません"));

  // ゲームIDの列が無いCSVは断る。
  const otherCsv = join(files, "other.csv");
  writeFileSync(otherCsv, "名前,内部ID,局数\r\nA,1,3\r\n");
  await popup.setInputFiles("#bulk-exported-file", otherCsv);
  await popup.waitForFunction(() => document.querySelector("#bulk-message").textContent.includes("「ゲームID」の列がありません"));
  assert.equal(await popup.textContent("#bulk-exported-text"), exportedText);

  // 読み込んだ一覧が表の対象になっている。
  assert.equal(await popup.inputValue("#target"), "list:202608-01.csv");
  await popup.screenshot({ path: join(shots, "6-bulk-loaded.png") });

  await popup.click("#bulk-start");
  await popup.waitForSelector("#bulk-stop:not([hidden])");

  // 1件目はすぐ取得し、次は20秒待つ(出力済みの対局は待たずに飛ばす)。
  await popup.waitForFunction(() => /次の取得まで \d+ 秒/.test(document.querySelector("#bulk-summary").textContent));
  await popup.screenshot({ path: join(shots, "7-bulk-running.png") });
  assert.equal(recordRequests.length, 1);
  assert.match(await popup.textContent("#bulk-summary"), /^取得中 2 \/ 5 件。次の取得まで \d+ 秒。残り約 1 分。$/);

  // 雀魂がエラーを返したら、その場で止まる。
  await popup.waitForFunction(() => document.querySelector("#bulk-summary").textContent.startsWith("停止"), null, {
    timeout: 100000,
  });
  assert.equal(
    await popup.textContent("#bulk-summary"),
    "停止: 雀魂がエラーを返しました (code 1203)。取得 2 件、取得済みで省略 0 件、出力済みで省略 1 件、失敗 1 件、未取得 1 件。",
  );
  assert.deepEqual(
    await popup.$$eval("#bulk-errors li", (lines) => lines.map((line) => line.textContent)),
    [`${ID_BAD}: 雀魂がエラーを返しました (code 1203)`],
  );
  await popup.screenshot({ path: join(shots, "8-bulk-halted.png") });

  // 出力済み(ID_DONE)は要求していない。エラーの後ろ(ID_E)にも要求を送っていない。
  await popup.waitForTimeout(1000);
  assert.deepEqual(recordRequests.map((request) => request.uuid), [ID_A, ID_B, ID_BAD]);
  assert.deepEqual(recordRequests.map((request) => request.version), [VERSION, VERSION, VERSION]);
  for (let i = 1; i < recordRequests.length; i++) {
    const gap = recordRequests[i].time - recordRequests[i - 1].time;
    assert.ok(gap >= INTERVAL_MS - JITTER_MS, `要求の間隔が ${gap}ms しかない`);
  }
  assert.deepEqual(await gameKeys(popup), [ID_A, ID_B].sort());
  assert.equal(await popup.textContent("#count"), "取得済み 2 対局、前回の出力から 1 対局");
  assert.equal(await popup.textContent("#bulk-list"), "取得する一覧: 202608-01.csv(5 対局、取得済み 2、出力済み 1、残り 2)");
  assert.equal(await worker.evaluate(() => chrome.action.getBadgeText({})), "2");
  // 拡張機能が送った要求への応答は、ページ(雀魂)には届いていない。
  assert.deepEqual(await game.evaluate(() => [window.received, window.unknown]), [3, 0]);

  // 表の中身(実牌譜と同じ対局なので、数字は実牌譜のもの)。
  const headers = await popup.$$eval("tr.columns th", (cells) => cells.map((cell) => cell.textContent));
  const rowCells = await popup.$$eval("tbody tr", (rows) =>
    rows.map((row) => Array.from(row.cells, (cell) => cell.textContent)),
  );
  const row = Object.fromEntries(headers.map((name, index) => [name, rowCells.find((cells) => cells[1] === "でぃすく。。。")[index]]));
  assert.deepEqual([row["和了数"], row["和了点合計"], row["副露回数"], row["最大連荘数"], row["最高和了点"]], ["3", "16000", "2", "2", "12000"]);
  assert.equal(headers.length, 93);

  await popup.click("#copy");
  const copied = await popup.evaluate(() => navigator.clipboard.readText());
  assert.ok(copied.startsWith("ゲームID\t名前\t内部ID\t局数\t最大連荘数\t和了数"));

  // ---- 保存するCSV: 保存先を選ぶ画面を出し、名前は対局一覧に合わせ、前回の出力の行も書き込む ----
  const saveCsv = async () => {
    await popup.waitForTimeout(2600); // 前の「CSVを保存した」の表示が消えるのを待つ
    const saved = await pressSave(popup);
    return { name: saved.name, lines: saved.text.replace(/^﻿/, "").trimEnd().split("\r\n") };
  };
  const gameIdsOf = (lines) => Array.from(new Set(lines.slice(1).map((line) => line.split(",")[0])));

  let saved = await saveCsv();
  assert.equal(saved.name, "202608-01-summary.csv");
  assert.deepEqual(gameIdsOf(saved.lines), [ID_DONE, ID_A, ID_B]);
  assert.equal(saved.lines.length, 1 + 2 + 4 + 4);
  assert.ok(saved.lines[0].startsWith("ゲームID,名前,内部ID"));
  // 前回のCSVに無かった「最大連荘数」は空欄で入る。
  assert.ok(saved.lines[1].startsWith(`${ID_DONE},前回A,102527752,8,,2,9000,`));

  // 保存したCSVは、そのまま次回の「出力済みのCSV」として読み込める。
  const nextCsv = join(files, "next-" + saved.name);
  writeFileSync(nextCsv, "﻿" + saved.lines.join("\r\n") + "\r\n");
  await popup.setInputFiles("#bulk-exported-file", nextCsv);
  await popup.waitForFunction(() => document.querySelector("#bulk-exported-text").textContent.includes("3 対局"));
  saved = await saveCsv();
  assert.equal(saved.lines.length, 1 + 2 + 4 + 4); // 拡張機能に残っている対局は二重にならない

  const header = saved.lines[0].split(",");
  const kbkn3 = saved.lines.find((line) => line.startsWith(`${ID_A},kbkn3,`)).split(",");
  const cell = (name) => kbkn3[header.indexOf(name)];
  assert.deepEqual(["七対子", "立直", "一発", "ロン和了", "ツモ和了", "断幺九"].map(cell), ["1", "1", "1", "1", "0", "0"]);
  console.log("対局一覧のCSVからの取得(省略・エラーで停止・CSVの保存): ok");

  // ---- 待機時間の入力欄と、残りの再開 ----
  // 既定は20秒。範囲(5〜600秒)の外の値は、始めるときに範囲内へ直す。
  assert.equal(await popup.inputValue("#bulk-interval"), "20");
  await popup.fill("#bulk-interval", "1");
  assert.equal(await popup.isVisible("#bulk-resume"), true);
  await popup.click("#bulk-resume");
  await popup.waitForFunction(() => document.querySelector("#bulk-summary").textContent.startsWith("完了"), null, {
    timeout: 60000,
  });
  assert.equal(await popup.inputValue("#bulk-interval"), "5");
  assert.equal(await popup.textContent("#bulk-summary"), "完了。取得 1 件、取得済みで省略 0 件、出力済みで省略 0 件、失敗 0 件。");
  assert.deepEqual(recordRequests.map((request) => request.uuid), [ID_A, ID_B, ID_BAD, ID_E]);
  assert.ok(recordRequests[3].time - recordRequests[2].time >= SHORT_INTERVAL_MS - JITTER_MS);

  // 出力済みの指定を解除して、同じ一覧をもう一度始める。取得済みの対局(ID_A, ID_B)は要求せず、残りだけ要求する。
  // 一覧の並びは A, DONE, B, BAD, E。BAD で止まるので、その後ろの E には進まない。
  await popup.click("#bulk-exported-clear");
  await popup.waitForSelector("#bulk-exported", { state: "hidden" });
  assert.equal(await popup.textContent("#bulk-list"), "取得する一覧: 202608-01.csv(5 対局、取得済み 3、残り 2)");
  await popup.click("#bulk-start");
  await popup.waitForFunction(() => document.querySelector("#bulk-summary").textContent.includes("取得済みで省略 2 件"), null, {
    timeout: 60000,
  });
  assert.equal(
    await popup.textContent("#bulk-summary"),
    "停止: 雀魂がエラーを返しました (code 1203)。取得 1 件、取得済みで省略 2 件、出力済みで省略 0 件、失敗 1 件、未取得 1 件。",
  );
  assert.deepEqual(recordRequests.slice(4).map((request) => request.uuid), [ID_DONE, ID_BAD]);

  // 対象を「すべての対局」にすると、名前は既定に戻る。
  await popup.selectOption("#target", "");
  saved = await saveCsv();
  assert.equal(saved.name, "majsoul-summary.csv");
  assert.deepEqual(gameIdsOf(saved.lines).sort(), [ID_A, ID_B, ID_DONE, ID_E].sort());
  await popup.screenshot({ path: join(shots, "9-all.png") });
  console.log("待機時間・再開・取得済みの省略: ok");

  // ======== 2つ目の一覧(雀魂自身の牌譜要求を雛形にする)、間隔の持ち越し、停止と再開 ========

  await game.goto("https://game.mahjongsoul.com/index.html?paipu=1");
  await game.waitForFunction(() => window.received === 4);
  const lastBulkRequest = recordRequests.filter((request) => request.uuid !== ORIGINAL).at(-1).time;
  recordRequests.length = 0;

  const list2 = writeList("202608-02.csv", [ID_C, ID_D, ORIGINAL]);
  await popup.setInputFiles("#bulk-list-file", list2);
  await popup.waitForFunction(() => document.querySelector("#bulk-message").textContent.includes("202608-02.csv"));
  assert.equal(await popup.inputValue("#target"), "list:202608-02.csv");
  assert.equal(await popup.textContent("#bulk-list"), "取得する一覧: 202608-02.csv(3 対局、取得済み 0、残り 3)");

  // 対象を選び直すと、取得する一覧もそれに合わせて替わる。
  await popup.selectOption("#target", "list:202608-01.csv");
  await popup.waitForFunction(() => document.querySelector("#bulk-list").textContent.startsWith("取得する一覧: 202608-01.csv("));
  await popup.selectOption("#target", "list:202608-02.csv");
  await popup.waitForFunction(() => document.querySelector("#bulk-list").textContent.startsWith("取得する一覧: 202608-02.csv("));

  assert.equal(await popup.inputValue("#bulk-interval"), "5"); // 待機時間は覚えている
  await popup.click("#bulk-start");
  // 2件取得して、3件目を待っているところまで進める。
  await popup.waitForFunction(() => /^取得中 2 \/ 3 件。次の取得まで/.test(document.querySelector("#bulk-summary").textContent), null, {
    timeout: 60000,
  });
  assert.equal(await popup.isDisabled("#bulk-interval"), true); // 取得中は待機時間を変えられない
  assert.deepEqual(recordRequests.map((request) => request.uuid), [ID_C, ID_D]);
  const shortGap = recordRequests[1].time - recordRequests[0].time;
  assert.ok(shortGap >= SHORT_INTERVAL_MS - JITTER_MS && shortGap < INTERVAL_MS, `待機が ${shortGap}ms だった`);
  // 止めて始め直しても、前回の要求から待機時間がたつまでは送らない。
  assert.ok(recordRequests[0].time - lastBulkRequest >= SHORT_INTERVAL_MS - JITTER_MS);
  assert.equal(recordRequests[0].version, VERSION);
  assert.equal(recordRequests[0].extra, 1); // 雛形にあった未知のフィールドも引き継ぐ

  await popup.click("#bulk-stop");
  await popup.waitForSelector("#bulk-resume:not([hidden])");
  assert.equal(
    await popup.textContent("#bulk-summary"),
    "停止: 止めました。取得 2 件、取得済みで省略 0 件、出力済みで省略 0 件、失敗 0 件、未取得 1 件。",
  );

  saved = await saveCsv();
  assert.equal(saved.name, "202608-02-summary.csv");
  assert.deepEqual(gameIdsOf(saved.lines).sort(), [ID_C, ID_D].sort());

  // ページが読み込み直されたら、取得中の表示は残らない。
  // 待機を20秒に戻してから再開する。次の要求まで間があるうちに読み込み直す。
  assert.equal(await popup.isDisabled("#bulk-interval"), false);
  await popup.fill("#bulk-interval", "20");
  await popup.click("#bulk-resume");
  await popup.waitForSelector("#bulk-stop:not([hidden])");
  await game.reload();
  await popup.waitForSelector("#bulk-resume:not([hidden])");
  const queue = await queueOf(popup);
  assert.equal(queue.state, "stopped");
  assert.equal(queue.reason, "雀魂のページが読み込み直されたため止まりました");
  assert.deepEqual(queue.items.map((item) => item.status), ["pending"]);
  // 一覧の3件目(ORIGINAL)は、拡張機能からは要求していない。雀魂が自分で開いた分は取り込んでいない。
  assert.equal(recordRequests.filter((request) => request.uuid !== ORIGINAL).length, 2);
  assert.equal((await gameKeys(popup)).includes(ORIGINAL), false);
  assert.deepEqual(await game.evaluate(() => window.unknown), 0);
  assert.deepEqual(pageErrors, []);
  console.log("2つ目の一覧(雛形・間隔の持ち越し・停止): ok");

  // ======== 広い画面と削除 ========

  const wide = await context.newPage();
  await wide.goto(`chrome-extension://${extensionId}/popup/popup.html?wide`);
  await wide.waitForSelector("#main:not([hidden])");
  assert.equal(await wide.inputValue("#bulk-interval"), "20"); // 開き直しても、最後に使った待機時間が残る
  assert.equal(await wide.inputValue("#target"), "list:202608-02.csv");
  await wide.screenshot({ path: join(shots, "5-wide.png"), fullPage: true });
  await wide.close();

  // 一覧を対象にした削除は、その一覧の対局だけを消し、一覧も忘れる。取得する一覧は、残っている一覧に替わる。
  assert.equal(await popup.textContent("#remove"), "この一覧の対局を削除");
  await popup.click("#remove");
  assert.equal(await popup.textContent("#remove"), "もう一度押すと削除");
  await popup.click("#remove");
  await popup.waitForFunction(() => document.querySelector("#target").value === "");
  assert.deepEqual(await gameKeys(popup), [ID_A, ID_B, ID_DONE, ID_E].sort());
  await popup.waitForFunction(() => document.querySelector("#bulk-list").textContent.startsWith("取得する一覧: 202608-01.csv("));
  assert.equal(await popup.textContent("#remove"), "すべての対局を削除");

  await popup.click("#remove");
  assert.equal(await popup.textContent("#remove"), "もう一度押すと削除");
  await popup.click("#remove");
  await popup.waitForSelector("#empty:not([hidden])");
  assert.equal(await worker.evaluate(() => chrome.action.getBadgeText({})), "");

  console.log("e2e ok");
} finally {
  await context.close();
  server.close();
}
