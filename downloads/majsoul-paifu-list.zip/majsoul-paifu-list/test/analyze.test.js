// 実行: node --test test/
const test = require("node:test");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

for (const file of ["schema", "fans", "pb", "analyze", "tables", "ids"]) require(`../src/${file}.js`);
const { pb, analyze, tables, ids } = globalThis.MPS;

// ---- 実際の牌譜(MahjongSoul-review-supporter のテスト用データ) ----

const raw = Uint8Array.from(
  Buffer.from(fs.readFileSync(path.join(__dirname, "fixtures/record-raw.base64.txt"), "utf8").trim(), "base64"),
);
const response = pb.decodeResponse(raw);
const actions = pb.decodeDetail(response.data);
const real = analyze.analyzeGame(response.head, actions);

function summaryOf(games) {
  const table = tables.summaryTable(games);
  return table.rows.map((row) => Object.fromEntries(table.columns.map((column, index) => [column, row[index]])));
}

test("実牌譜: ヘッダと局イベントを読める", () => {
  assert.equal(response.head.uuid, "260520-a9ac4630-6d4c-49e4-8f72-93d5d6080eee");
  assert.equal(actions.length, 1211);
  assert.deepEqual(
    real.players.map((player) => player.name),
    ["でぃすく。。。", "バイト先の鳥", "kbkn3", "神楽めあ0w0"],
  );
  assert.equal(real.roundCount, 12);
  assert.deepEqual(real.unknownActions, []);
});

test("実牌譜: 生のイベントを素朴に数え直した値と一致する", () => {
  // 集計処理とは別の、単純な数え方で検算する。
  const wins = [0, 0, 0, 0];
  const dealIns = [0, 0, 0, 0];
  const declared = [0, 0, 0, 0];
  const callRounds = [0, 0, 0, 0];
  const callCount = [0, 0, 0, 0];
  let lastDiscarder = -1;
  let calledThisRound = new Set();
  for (const action of actions) {
    const event = action.data;
    if (action.name === "RecordNewRound") calledThisRound = new Set();
    if (action.name === "RecordDiscardTile") {
      lastDiscarder = event.seat;
      if (event.is_liqi) declared[event.seat]++;
    }
    if (action.name === "RecordChiPengGang") {
      callCount[event.seat]++;
      if (!calledThisRound.has(event.seat)) callRounds[event.seat]++;
      calledThisRound.add(event.seat);
    }
    if (action.name === "RecordHule") {
      for (const hule of event.hules) {
        wins[hule.seat]++;
        if (!hule.zimo) dealIns[lastDiscarder]++;
      }
    }
  }
  const rows = summaryOf([real]);
  assert.deepEqual(rows.map((row) => row["和了数"]), wins);
  assert.deepEqual(rows.map((row) => row["放銃数"]), dealIns);
  assert.deepEqual(rows.map((row) => row["立直数"]), declared); // この対局に不成立の立直は無い
  assert.deepEqual(rows.map((row) => row["副露局数"]), callRounds);
  assert.deepEqual(rows.map((row) => row["副露回数"]), callCount);
  assert.deepEqual(rows.map((row) => row["局数"]), [12, 12, 12, 12]);
});

test("実牌譜: 和了点+本場+供託が、雀魂の記録した点数移動と一致する", () => {
  // 和了点(本場・供託を除く手の点数)と、立直の成立判定の両方を、牌譜の点数移動で検算する。
  let roundIndex = -1;
  let start = null;
  let checked = 0;
  for (const action of actions) {
    if (action.name === "RecordNewRound") {
      roundIndex++;
      start = action.data;
    }
    if (action.name !== "RecordHule") continue;
    const rows = real.hules.filter((hule) => hule.roundIndex === roundIndex);
    assert.equal(rows.length, 1, "この対局にダブロンは無い");
    const hule = rows[0];
    const sticks = start.liqibang + real.riichis.filter((r) => r.roundIndex === roundIndex && r.established).length;
    assert.equal(action.data.delta_scores[hule.winner], hule.points + start.ben * 300 + sticks * 1000);
    if (!hule.zimo) assert.equal(action.data.delta_scores[hule.loser], -(hule.points + start.ben * 300));
    checked++;
  }
  assert.equal(checked, 8);
});

test("実牌譜: 牌譜を目で追って確かめた行", () => {
  // 最初の和了: 東2局1本場、kbkn3 が神楽めあ0w0 から七対子・立直・一発をロン。
  const first = real.hules[0];
  assert.deepEqual(
    {
      局: first.round,
      本場: first.honba,
      和了者: real.players[first.winner].name,
      ツモ: first.zimo,
      放銃者: real.players[first.loser].name,
      和了点: first.points,
      巡目: first.turn,
      飜: first.han,
      符: first.fu,
      役: first.yaku,
      和了者の状態: first.winnerState,
      放銃者の状態: first.loserState,
    },
    {
      局: "東2局",
      本場: 1,
      和了者: "kbkn3",
      ツモ: 0,
      放銃者: "神楽めあ0w0",
      和了点: 6400,
      巡目: 11,
      飜: 4,
      符: 25,
      役: "七対子(2)、立直(1)、一発(1)",
      和了者の状態: "立直",
      放銃者の状態: "立直中",
    },
  );

  // 東2局1本場: 神楽めあ0w0 が10巡目に先制立直、kbkn3 が11巡目に追っかけて一発ロン。
  const riichis = real.riichis.filter((riichi) => riichi.roundIndex === 1);
  assert.deepEqual(
    riichis.map((r) => [real.players[r.seat].name, r.turn, r.first, r.chase, r.order, r.result]),
    [
      ["神楽めあ0w0", 10, 1, 0, 1, "放銃"],
      ["kbkn3", 11, 0, 1, 2, "ロン和了"],
    ],
  );
  const kagura = summaryOf([real])[3];
  assert.equal(kagura["立直後放銃"], 1);
});

test("実牌譜: 最大連荘数・最高和了点・巡目の合計", () => {
  const rows = summaryOf([real]);
  // 局の並び: 東1 東2 東3 東4 東4 南1 南1 南2 南2 南2 南3 南4。
  // 起家から順に、南1を2局、南2を3局、連荘なし(1局ずつ)、東4を2局。
  assert.deepEqual(rows.map((row) => row["最大連荘数"]), [2, 3, 1, 2]);
  assert.deepEqual(rows.map((row) => row["最高和了点"]), [12000, 6000, 6400, 1300]);
  assert.deepEqual(rows.map((row) => row["和了巡目合計"]), [28, 23, 11, 19]);
  assert.deepEqual(rows.map((row) => row["立直巡目合計"]), [9, 38, 11, 42]);
  assert.equal(rows[0]["和了巡目平均"], 9.3); // 28 / 3
  assert.equal(rows[3]["立直巡目平均"], 8.4); // 42 / 5

  // 最大連荘数を、局の開始イベントから別のやり方で数え直す。
  const longest = [0, 0, 0, 0];
  const starts = actions.filter((action) => action.name === "RecordNewRound").map((action) => action.data);
  for (let from = 0; from < starts.length; ) {
    let to = from;
    while (to + 1 < starts.length && starts[to + 1].chang === starts[from].chang && starts[to + 1].ju === starts[from].ju) to++;
    longest[starts[from].ju] = Math.max(longest[starts[from].ju], to - from + 1);
    from = to + 1;
  }
  assert.deepEqual(real.maxDealerRun, longest);
});

test("最大連荘数: 親を続けた局数の最大。親を3局続けたら3", () => {
  const game = analyze.analyzeGame(head("g7", NAMES), [
    newRound(0, 0), noTile(),
    newRound(0, 0, 1), noTile(),
    newRound(0, 0, 2), noTile(), // 東家が3局続けた = 3
    newRound(0, 1, 3), noTile(), // 南家は1局で流れた = 1
    newRound(0, 2), noTile(),
    newRound(0, 2, 1), noTile(), // 西家が2局 = 2
    newRound(0, 3), noTile(),
    newRound(1, 0), noTile(), // 南1局は東1局の続きではない
    newRound(1, 0, 1), noTile(),
  ]);
  assert.deepEqual(game.maxDealerRun, [3, 1, 2, 1]);
  assert.deepEqual(summaryOf([game]).map((row) => row["最大連荘数"]), [3, 1, 2, 1]);
  assert.deepEqual(summaryOf([game]).map((row) => row["最高和了点"]), ["", "", "", ""]); // 和了なし

  // 親番が来る前に終わった対局では、来なかった人は0。
  const short = analyze.analyzeGame(head("g8", NAMES), [newRound(0, 0), noTile(), newRound(0, 0, 1), noTile()]);
  assert.deepEqual(short.maxDealerRun, [2, 0, 0, 0]);
});

test("最大連荘数: 古い版で取り込んだ対局", () => {
  const game = analyze.analyzeGame(head("g9", NAMES), [newRound(0, 0), noTile(), newRound(0, 0, 1), noTile(), newRound(0, 1, 2), noTile()]);
  assert.deepEqual(summaryOf([game]).map((row) => row["最大連荘数"]), [2, 1, 0, 0]);

  // v0.8.0 の保存データ: 「親が続いた回数」で記録していた。1を足して局数に直す。
  delete game.maxDealerRun;
  game.maxRenchan = [1, 0, 0, 0];
  assert.deepEqual(summaryOf([game]).map((row) => row["最大連荘数"]), [2, 1, 1, 1]);

  // それより前の保存データ: 記録が無いので空欄。
  delete game.maxRenchan;
  assert.deepEqual(summaryOf([game]).map((row) => row["最大連荘数"]), ["", "", "", ""]);
});

// ---- 手で組んだ牌譜(実牌譜に出てこない形を確かめる) ----

function head(uuid, names, ids) {
  return {
    uuid,
    start_time: 1000,
    end_time: 2000,
    accounts: names.map((nickname, seat) => ({ seat, nickname, account_id: ids ? ids[seat] : seat + 1 })),
    result: { players: names.map((_, seat) => ({ seat })) },
  };
}
const NAMES = ["東家", "南家", "西家", "北家"];
const newRound = (chang, ju, ben = 0) => ({ name: "RecordNewRound", data: { chang, ju, ben, liqibang: 0 } });
const deal = (seat) => ({ name: "RecordDealTile", data: { seat } });
const discard = (seat, extra = {}) => ({
  name: "RecordDiscardTile",
  data: { seat, tile: "1m", is_liqi: false, is_wliqi: false, ...extra },
});
const call = (seat, type) => ({ name: "RecordChiPengGang", data: { seat, type } });
const kan = (seat, type) => ({ name: "RecordAnGangAddGang", data: { seat, type } });
const hule = (...hules) => ({ name: "RecordHule", data: { hules } });
const win = (seat, zimo, dadian, fans = [], extra = {}) => ({
  seat, zimo, qinjia: false, liqi: false, yiman: false, count: 1, fu: 30, fans, dadian, ...extra,
});
const noTile = () => ({ name: "RecordNoTile", data: {} });
const abort = () => ({ name: "RecordLiuJu", data: {} });
// seat から順に1人1打ずつ、turns 巡ぶん進める。
function go(turns) {
  const out = [];
  for (let turn = 0; turn < turns; turn++) for (let seat = 0; seat < 4; seat++) out.push(deal(seat), discard(seat));
  return out;
}

test("宣言牌でロンされた立直は成立しない", () => {
  const game = analyze.analyzeGame(head("g1", NAMES), [
    newRound(0, 0),
    ...go(3),
    deal(0),
    discard(0, { is_liqi: true }),
    hule(win(1, false, 8000)),
  ]);
  assert.equal(game.riichis.length, 1);
  assert.equal(game.riichis[0].established, 0);
  assert.equal(game.riichis[0].result, "宣言牌で放銃");
  assert.equal(game.hules[0].loserState, "立直宣言牌");
  assert.equal(game.hules[0].turn, 4);
  const east = summaryOf([game])[0];
  assert.equal(east["立直数"], 0);
  assert.equal(east["放銃数"], 1);
  assert.equal(east["立直後放銃"], 0);
  assert.equal(east["放銃点合計"], 8000);
});

test("先制と追っかけ、立直後の結果", () => {
  const game = analyze.analyzeGame(head("g2", NAMES), [
    newRound(0, 0),
    ...go(2),
    deal(0),
    discard(0, { is_liqi: true }), // 東家: 3巡目に先制
    deal(1),
    discard(1),
    deal(2),
    discard(2, { is_liqi: true }), // 西家: 3巡目に追っかけ
    deal(3),
    discard(3),
    deal(0),
    discard(0), // 東家が西家に放銃
    hule(win(2, false, 3900, [{ id: 2, val: 1 }, { id: 31, val: 2 }, { id: 33, val: 1 }], { liqi: true })),
    newRound(0, 1),
    ...go(1),
    deal(0),
    discard(0, { is_wliqi: true }),
    deal(1),
    hule(win(1, true, 2000, [{ id: 1, val: 1 }])), // 南家がツモ
    newRound(0, 2),
    deal(0),
    discard(0, { is_liqi: true }),
    deal(1),
    discard(1),
    noTile(),
    newRound(0, 3),
    deal(0),
    discard(0, { is_liqi: true }),
    deal(1),
    discard(1),
    deal(2),
    discard(2), // 西家が北家に放銃(東家の立直は横移動)
    hule(win(3, false, 1000)),
    newRound(1, 0),
    deal(0),
    discard(0, { is_liqi: true }),
    abort(),
  ]);
  assert.deepEqual(
    game.riichis.map((r) => [r.round, r.seat, r.turn, r.first, r.chase, r.order, r.double, r.result, r.win]),
    [
      ["東1局", 0, 3, 1, 0, 1, 0, "放銃", 0],
      ["東1局", 2, 3, 0, 1, 2, 0, "ロン和了", 1],
      ["東2局", 0, 2, 1, 0, 1, 1, "被ツモ", 0],
      ["東3局", 0, 1, 1, 0, 1, 0, "流局", 0],
      ["東4局", 0, 1, 1, 0, 1, 0, "横移動", 0],
      ["南1局", 0, 1, 1, 0, 1, 0, "途中流局", 0],
    ],
  );
  const [first] = game.hules;
  assert.equal(first.turn, 4); // 放銃牌は東家の4打目
  assert.equal(first.loserState, "立直中");
  assert.equal(first.winnerState, "立直");
  assert.deepEqual([first.dora, first.akaDora, first.uraDora, first.ippatsu], [2, 0, 1, 0]);
  assert.equal(first.yaku, "立直(1)"); // ドラ類は役の欄に入れない
  assert.equal(game.hules[1].turn, 2); // ツモ和了は本人の打牌数+1

  const rows = summaryOf([game]);
  assert.equal(rows[0]["立直数"], 5);
  assert.equal(rows[0]["先制立直"], 5);
  assert.equal(rows[0]["立直和了"], 0);
  assert.equal(rows[0]["立直後放銃"], 1);
  assert.equal(rows[0]["立直巡目平均"], 1.6); // (3+2+1+1+1)/5
  assert.equal(rows[2]["立直数"], 1);
  assert.equal(rows[2]["追っかけ立直"], 1);
  assert.equal(rows[2]["立直和了"], 1);
  assert.equal(rows[2]["ドラ"], 2);
  assert.equal(rows[2]["裏ドラ"], 1);
});

test("ダブロンは放銃1回、点数は合算", () => {
  const game = analyze.analyzeGame(head("g3", NAMES), [
    newRound(0, 0),
    ...go(5),
    deal(0),
    discard(0),
    hule(win(1, false, 8000), win(3, false, 3900)),
  ]);
  const east = summaryOf([game])[0];
  assert.equal(east["放銃数"], 1);
  assert.equal(east["放銃点合計"], 11900);
  assert.equal(east["放銃点平均"], 11900);
  assert.equal(game.hules.length, 2);
  assert.equal(Object.hasOwn(east, "放銃先"), false); // 放銃先の列は出さない
});

test("副露: チー・ポン・大明槓だけを数える", () => {
  const game = analyze.analyzeGame(head("g4", NAMES), [
    newRound(0, 0),
    deal(0),
    discard(0),
    call(1, 0), // チー
    discard(1),
    deal(2),
    discard(2),
    call(1, 1), // ポン
    discard(1),
    deal(2),
    kan(2, 3), // 暗槓は副露に数えない
    deal(2),
    discard(2),
    deal(1),
    kan(1, 2), // 加槓は回数に足さない
    hule(win(3, false, 2600)), // 槍槓: 加槓した南家が放銃
    newRound(0, 1),
    deal(1),
    discard(1),
    call(3, 2), // 大明槓
    deal(3),
    hule(win(3, true, 4000, [{ id: 4, val: 1 }])),
    newRound(0, 2),
    ...go(1),
    noTile(),
  ]);
  assert.deepEqual(game.callCount, [0, 2, 0, 1]);
  assert.deepEqual(game.callRounds, [0, 1, 0, 1]);
  const chankan = game.hules[0];
  assert.equal(chankan.loser, 1);
  assert.equal(chankan.turn, 3); // 南家は2打済みで、3回目の手番に加槓した
  assert.equal(chankan.loserState, "副露");
  assert.equal(chankan.winnerState, "ダマ");
  const rows = summaryOf([game]);
  assert.equal(rows[3]["副露和了"], 1);
  assert.equal(rows[3]["副露局数"], 1);
  assert.equal(rows[3]["和了数"], 2);
  assert.equal(rows[2]["副露局数"], 0);
});

test("役満は、役満の倍数と役満の役だけを記録する", () => {
  const game = analyze.analyzeGame(head("g5", NAMES), [
    newRound(0, 0),
    ...go(1),
    deal(0),
    hule(win(0, true, 48000, [{ id: 42, val: 1 }], { yiman: true, count: 1, qinjia: true })),
  ]);
  const [only] = game.hules;
  assert.deepEqual([only.han, only.fu, only.yakuman, only.yaku], [0, 0, 1, "国士無双"]);
});

test("出力: TSVとCSVの整形", () => {
  const table = { columns: ["名前", "値"], rows: [["a\tb", 1], ['x,"y"', ""]] };
  assert.equal(tables.toTSV(table, true), '名前\t値\na b\t1\nx,"y"\t\n');
  assert.equal(tables.toTSV(table, false), 'a b\t1\nx,"y"\t\n');
  assert.equal(tables.toCSV(table), '名前,値\r\na\tb,1\r\n"x,""y""",\r\n');
});

test("デコーダ: 負の数・まとめて入った数値・未知のフィールド", () => {
  // RecordHule{ old_scores:[25000], delta_scores:[-8000, 8000], 未知のフィールド99 }
  const bytes = Uint8Array.from([
    0x12, 0x03, 0xa8, 0xc3, 0x01, // old_scores (packed) 25000
    0x1a, 0x0c, 0xc0, 0xc1, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x01, 0xc0, 0x3e, // delta_scores -8000, 8000
    0x98, 0x06, 0x05, // field 99, varint 5
  ]);
  const decoded = pb.decode("RecordHule", bytes);
  assert.deepEqual(decoded.old_scores, [25000]);
  assert.deepEqual(decoded.delta_scores, [-8000, 8000]);
  assert.deepEqual(decoded.hules, []);
});

test("ゲームIDの読み取り: URLや余計な文字が付いていても拾い、重複は除く", () => {
  const a = "250929-b8c95b66-5994-48f4-b47f-c25bf7047ab8";
  const b = "261004-42dc93b3-b750-4a11-88ec-21a68ae4193a";
  const text = [
    a,
    "",
    `https://game.mahjongsoul.com/?paipu=${b}_a433151786`,
    "牌譜はこれ",
    `  ${a.toUpperCase()}  `,
    `${b},あるですけど,61200`,
    "jijpjn-q4r88y45-xxxx",
  ].join("\r\n");
  assert.deepEqual(ids.extract(text), { uuids: [a, b], unreadable: 2 });
  assert.deepEqual(ids.extract(""), { uuids: [], unreadable: 0 });
});

test("対局一覧のCSV: 「牌譜リンク」の列からゲームIDを拾う", () => {
  // 雀魂の大会の対局一覧と同じ見出し。名前や備考にカンマ・改行・IDに似た文字が入っていても列を取り違えない。
  const header =
    "開始時間,終了時間,非表示状態,1位プレイヤー名,1位PT,1位最終点数,2位プレイヤー名,2位PT,2位最終点数," +
    "3位プレイヤー名,3位PT,3位最終点数,4位プレイヤー名,4位PT,4位最終点数,牌譜リンク,備考";
  const a = "260930-622a4d6f-ff3a-4dfe-8a67-676178fa905d";
  const b = "260930-a423ab2c-24e5-4513-9882-039a781c89e7";
  const decoy = "260101-00000000-0000-4000-8000-000000000000";
  const row = (name, link, note) =>
    `2026-09-30 22:08:22,2026-09-30 22:53:06,no,${name},34300,54.3,[JP][2]B(),25300,5.3,[JP][3]C(),22500,-17.5,[JP][4]D(),17900,-42.1,${link},${note}`;
  const text = [header, row("[JP][1]A()", a, ""), row('"[JP][1]あ,い()"', b, `"再戦\n${decoy} の代わり"`), row("[JP][1]A()", a, ""), ""].join("\r\n");

  assert.equal(ids.parseCSV(text).length, 4);
  assert.deepEqual(ids.fromGameList("\ufeff" + text.replace(/^/, "")), { uuids: [a, b], column: true });
  // 見出しが違うCSVは、ファイル全体から拾う。
  assert.deepEqual(ids.fromGameList(`id,memo\n${a},x\n${b},y\n`), { uuids: [a, b], column: false });
  assert.deepEqual(ids.fromGameList("何もない"), { uuids: [], column: false });
});

test("出力済みのCSV: この拡張機能が保存した集計CSVの「ゲームID」の列を読む", () => {
  const other = analyze.analyzeGame(head("261001-aaaaaaaa-1111-4111-8111-aaaaaaaaaaaa", NAMES), [newRound(0, 0), noTile()]);
  const csv = "\ufeff" + tables.toCSV(tables.summaryTable([real, other]));
  const text = ids.decodeFile(new TextEncoder().encode(csv));
  assert.deepEqual(ids.fromExported(text).sort(), [real.uuid, other.uuid].sort());
  // ゲームIDの列が無いCSVは、読めないことを伝える。
  assert.equal(ids.fromExported("名前,内部ID,局数\r\nA,1,8\r\n"), null);
});

test("CSVの文字コード: UTF-8で読めなければShift_JISで読む", () => {
  // 「牌譜リンク」をShift_JISで書いたもの
  const sjis = Uint8Array.from([0x94, 0x76, 0x95, 0x88, 0x83, 0x8a, 0x83, 0x93, 0x83, 0x4e]);
  assert.equal(ids.decodeFile(sjis), "牌譜リンク");
  assert.equal(ids.decodeFile(new TextEncoder().encode("\ufeff牌譜リンク")), "牌譜リンク");
});

// ---- 前回の出力の引き継ぎ ----

// 集計表をCSVに保存し、「出力済みのCSV」として読み直したもの。
function savedAndReloaded(games) {
  return ids.readExported(ids.decodeFile(new TextEncoder().encode("\ufeff" + tables.toCSV(tables.summaryTable(games)))));
}

function twoGames() {
  const first = analyze.analyzeGame(head("260901-aaaaaaaa-1111-4111-8111-aaaaaaaaaaaa", NAMES, [11, 12, 13, 14]), [
    newRound(0, 0),
    ...go(4),
    deal(0),
    hule(win(0, true, 2000)), // 5巡目
  ]);
  // 2戦目は席も名前も違うが、内部ID 11 は同じ人。
  const second = analyze.analyzeGame(head("260902-bbbbbbbb-2222-4222-8222-bbbbbbbbbbbb", ["A", "B", "改名後", "D"], [21, 22, 11, 24]), [
    newRound(0, 0),
    ...go(8),
    deal(0),
    discard(0),
    hule(win(2, false, 8000)), // 東家の9打目でロン
    newRound(0, 1),
    noTile(),
  ]);
  second.endTime = 3000;
  return [first, second];
}

test("前回の出力: 保存したCSVを読み直すと、同じ行がそのまま次の出力に入る", () => {
  const [first, second] = twoGames();
  const before = tables.summaryTable([real, first, second]);
  const carried = savedAndReloaded([real, first, second]);
  assert.equal(carried.uuids.length, 3);

  // 拡張機能から全部消した後でも、前回の出力だけで同じ表になる。
  assert.deepEqual(tables.summaryTable([], carried).rows, before.rows);
  // 一部が拡張機能に残っていても重複しない。残っている対局は取り込み済みのデータから作る。
  const mixed = tables.summaryTable([second], carried).rows;
  assert.equal(mixed.length, 12);
  assert.deepEqual(mixed.map((row) => row[0]).filter((uuid, index, all) => all.indexOf(uuid) === index).sort(), [real.uuid, first.uuid, second.uuid].sort());
  assert.deepEqual(mixed.slice(8), tables.summaryTable([second]).rows);
  assert.deepEqual(tables.carriedGameIds([second], carried).sort(), [real.uuid, first.uuid].sort());
  assert.deepEqual(tables.carriedGameIds([real, first, second], carried), []);
});

test("前回の出力: 対局一覧で絞り込める。列の並びや過不足が違っても見出しで合わせる", () => {
  const [first, second] = twoGames();
  const carried = savedAndReloaded([first, second]);
  const limited = tables.limitCarried(carried, new Set([second.uuid]));
  assert.deepEqual(tables.summaryTable([], limited).rows, tables.summaryTable([second]).rows);
  assert.equal(tables.limitCarried(null, new Set()), null);

  // 列が入れ替わり、知らない列が増え、足りない列があるCSV。ゲームIDは大文字。
  const odd = {
    columns: ["メモ", "名前", "ゲームID", "和了数", "内部ID"],
    rows: [["x", "123", first.uuid.toUpperCase(), "2", "11"]],
  };
  const row = tables.summaryTable([], odd).rows[0];
  const byName = Object.fromEntries(tables.summaryTable([], odd).columns.map((name, index) => [name, row[index]]));
  assert.equal(byName["ゲームID"], first.uuid);
  assert.equal(byName["名前"], "123"); // 名前は数字に見えても文字のまま
  assert.equal(byName["内部ID"], 11);
  assert.equal(byName["和了数"], 2);
  assert.equal(byName["局数"], "");
  assert.equal(row.length, tables.summaryTable([]).columns.length);
});

// ---- 役の列と、和了・放銃の追加項目 ----

test("集計の列: 見出しは重複せず、分類の幅の合計と列数が一致する", () => {
  const table = tables.summaryTable([]);
  assert.equal(new Set(table.columns).size, table.columns.length);
  assert.equal(table.groups.reduce((sum, group) => sum + group.span, 0), table.columns.length);
  assert.equal(tables.YAKU_COLUMNS.length, 60);
  // ドラの類は役の列にしない(枚数として別の列にある)。人和は番号が2つあるが1列。
  for (const name of ["ドラ", "赤ドラ", "裏ドラ", "抜きドラ"]) assert.equal(tables.YAKU_COLUMNS.includes(name), false);
  assert.equal(tables.YAKU_COLUMNS.filter((name) => name === "人和").length, 1);
  assert.equal(table.columns.at(-1), "その他の役");
});

test("実牌譜: 役の列は、和了の明細を数え直した値と一致する", () => {
  const rows = summaryOf([real]);
  rows.forEach((row, seat) => {
    const wins = real.hules.filter((hule) => hule.winner === seat);
    // 明細の役の欄を、集計とは別のやり方(名前で探す)で数える。
    for (const yaku of tables.YAKU_COLUMNS) {
      const expected = wins.filter((hule) => hule.yaku.split("、").some((piece) => piece === yaku || piece.startsWith(yaku + "("))).length;
      assert.equal(row[yaku], expected, `${row["名前"]} の ${yaku}`);
    }
    assert.equal(row["その他の役"], 0);
    assert.equal(row["ツモ和了"], wins.filter((hule) => hule.zimo).length);
    assert.equal(row["ロン和了"], wins.filter((hule) => !hule.zimo).length);
    assert.equal(row["ツモ和了"] + row["ロン和了"], row["和了数"]);
    assert.equal(row["ダマ和了"], wins.filter((hule) => hule.winnerState === "ダマ").length);
    assert.equal(row["ダマ和了"] + row["立直和了"] + row["副露和了"], row["和了数"]);
    assert.equal(row["役満和了"], 0);
    assert.equal(row["最高和了点"], wins.length ? Math.max(...wins.map((hule) => hule.points)) : "");
    assert.equal(row["和了巡目合計"], wins.reduce((sum, hule) => sum + hule.turn, 0));
  });
  // 牌譜を目で追って確かめた値。
  const disk = rows[0]; // でぃすく。。。: 白のみ / 断幺九・ツモ・立直・一発 / 中のみ
  assert.deepEqual(
    ["役牌 白", "役牌 中", "断幺九", "門前清自摸和", "立直", "一発", "平和"].map((name) => disk[name]),
    [1, 1, 1, 1, 1, 1, 0],
  );
  const bird = rows[1]; // バイト先の鳥: 断幺九(副露ツモ) / 門前清自摸和・平和(ダマ)
  assert.deepEqual([bird["断幺九"], bird["門前清自摸和"], bird["平和"], bird["ダマ和了"], bird["ツモ和了"]], [1, 1, 1, 1, 2]);
});

test("役満・知らない役・宣言牌放銃", () => {
  const game = analyze.analyzeGame(head("g6", NAMES), [
    newRound(0, 0),
    ...go(1),
    deal(0),
    hule(win(0, true, 96000, [{ id: 42, val: 1 }, { id: 39, val: 1 }], { yiman: true, count: 2, qinjia: true })),
    newRound(0, 0, 1),
    ...go(1),
    deal(0),
    // 定義に無い番号の役(イベント用など)は「その他の役」に数える。
    hule(win(0, true, 2000, [{ id: 999, val: 1 }, { id: 12, val: 1 }, { id: 31, val: 2 }])),
    newRound(0, 0, 2),
    deal(0),
    discard(0, { is_liqi: true }),
    hule(win(1, false, 8000, [{ id: 59, val: 5 }])), // 人和
  ]);
  const [east, south] = summaryOf([game]);
  assert.equal(east["役満和了"], 1);
  assert.deepEqual([east["国士無双"], east["字一色"], east["断幺九"], east["その他の役"], east["ドラ"]], [1, 1, 1, 1, 2]);
  assert.deepEqual([east["宣言牌放銃"], east["立直後放銃"], east["放銃数"], east["立直数"]], [1, 0, 1, 0]);
  assert.equal(south["人和"], 1);
});

test("前回の出力: 役の列が無い古いCSVを引き継ぐと、役の列は空欄。「一発」は見出しが同じなので引き継がれる", () => {
  const old = {
    columns: ["ゲームID", "名前", "内部ID", "局数", "和了数", "一発"],
    rows: [["260901-aaaaaaaa-1111-4111-8111-aaaaaaaaaaaa", "A", "1", "8", "2", "1"]],
  };
  const table = tables.summaryTable([], old);
  const row = Object.fromEntries(table.columns.map((column, index) => [column, table.rows[0][index]]));
  assert.deepEqual([row["和了数"], row["一発"], row["立直"], row["ツモ和了"]], [2, 1, "", ""]);
});
